<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" 
    integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" 
    crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="thongtin.css">
    <title>Document</title>
</head>
<body>
    <div class="dropdown">
        <div class="dropdown_select">
            <span class="dropdown_selected">
                your account
            </span>
            <i class="fa fa-caret-down dropdown_caret"></i>
        </div>
        <div class="dropdown_list">
            <div class="dropdown_item">
                <span class="dropdown_text">
                    New information
                </span>
                <i class="fa fa-plus-circle dropdown_icon"></i>
            </div>
            <div class="dropdown_item">
                <span class="dropdown_text">
                    View information
                </span>
                <a href="thongtin_user.php"><i class="fa fa-user dropdown_icon"></i></a>
                
            </div>
            <div class="dropdown_item">
                <span class="dropdown_text">
                    Settings
                </span>
                <i class="fa fa-cog dropdown_icon"></i>
            </div>
            <div class="dropdown_item">
                <span class="dropdown_text">
                    Logout
                </span>
                <a href="../login/logout.php"><i class="fa-solid fa-power-off"></i></a>
            </div>
        </div>
    </div>
</body>
</html>