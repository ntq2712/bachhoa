
<?php
    include "header.php";
?>

<section class="event">
<div class="event-top">
            <img id="hinh" src="../uploads/khuyenmai1.jpg" alt="">
            <div class="control">
                <i class="fa fa-circle-chevron-left" onclick="trai()"></i>
                <i class="fa fa-circle-chevron-right" onclick="phai()"></i>
            </div>
        </div>
        <div class="event-contener-top">
            <h1>KHUYẾN MÃI CỰC SỐC</h1>
        </div>
        <div class="event-contener">
            <div class="event-contener-item">
                <img src="../uploads/cam.jpg" alt="">
                <div class="desc">
                        Loại: Rau <br>
                        Khối lượng: 1kg <br>
                        Giá đã giảm: <span style="color: red;">29.000</span> <sup>đ</sup> <br>
                        Chi tết: Tên khoa học là Brassica oleracea 
                        var capitata ruba là cây bắp cải có màu tím.
                </div>
                <h2>CẢI TÍM - 250g</h2>
                <p>30.000<sup>đ</sup></p>
                <button>MUA</button>
            </div>
            <div class="event-contener-item">
                <img src="../uploads/dudu.jpg" alt="">
                <div class="desc">
                        Loại: Rau <br>
                        Khối lượng: 1kg <br>
                        Giá đã giảm: <span style="color: red;">29.000</span> <sup>đ</sup> <br>
                        Chi tết: Tên khoa học là Brassica oleracea 
                        var capitata ruba là cây bắp cải có màu tím.
                </div>
                <h2>CẢI TÍM - 250g</h2>
                <p>30.000<sup>đ</sup></p>
                <button>MUA</button>
            </div>
            <div class="event-contener-item">
                <img src="../uploads/bapcaitrang.jpg" alt="">
                <div class="desc">
                        Loại: Rau <br>
                        Khối lượng: 1kg <br>
                        Giá đã giảm: <span style="color: red;">29.000</span> <sup>đ</sup> <br>
                        Chi tết: Tên khoa học là Brassica oleracea 
                        var capitata ruba là cây bắp cải có màu tím.
                </div>
                <h2>CẢI TÍM - 250g</h2>
                <p>30.000<sup>đ</sup></p>
                <button>MUA</button>
            </div>
            <div class="event-contener-item">
                <img src="../uploads/cannuoc.jpg" alt="">
                <div class="desc">
                        Loại: Rau <br>
                        Khối lượng: 1kg <br>
                        Giá đã giảm: <span style="color: red;">29.000</span> <sup>đ</sup> <br>
                        Chi tết: Tên khoa học là Brassica oleracea 
                        var capitata ruba là cây bắp cải có màu tím.
                </div>
                <h2>CẢI TÍM - 250g</h2>
                <p>30.000<sup>đ</sup></p>
                <button>MUA</button>
            </div>
            <div class="event-contener-item">
                <img src="../uploads/ngotay.jpg" alt="">
                <div class="desc">
                        Loại: Rau <br>
                        Khối lượng: 1kg <br>
                        Giá đã giảm: <span style="color: red;">29.000</span> <sup>đ</sup> <br>
                        Chi tết: Tên khoa học là Brassica oleracea 
                        var capitata ruba là cây bắp cải có màu tím.
                </div>
                <h2>CẢI TÍM - 250g</h2>
                <p>30.000<sup>đ</sup></p>
                <button>MUA</button>
            </div>
            <div class="event-contener-item">
                <img src="../uploads/suplo.jpg" alt="">
                <div class="desc">
                        Loại: Rau <br>
                        Khối lượng: 1kg <br>
                        Giá đã giảm: <span style="color: red;">29.000</span> <sup>đ</sup> <br>
                        Chi tết: Tên khoa học là Brassica oleracea 
                        var capitata ruba là cây bắp cải có màu tím.
                </div>
                <h2>CẢI TÍM - 250g</h2>
                <p>30.000<sup>đ</sup></p>
                <button>MUA</button>
            </div>
        </div>
        <div class="event-other-top">
            <i class="fa-solid fa-gift"></i>
            <h1>TRÁI CÂY CÁC LOẠI</h1>
            <div class="event-other-top-item">
                <p>28 khuyến mãi hấp dẫn</p>
            </div>
            <div class="event-other-top-item">
                <p>Trái cây nhập khẩu</p>
            </div>
            <div class="event-other-top-item">
                <p>Trái cây nội địa</p>
            </div>
            <div class="event-other-top-item">
                <p>Trái cây sấy khô</p>
            </div>
        </div>
        <div class="event-other">
            <div class="event-other-item">
                <img src="../uploads/cam.jpg" alt="">
                <div class="desc">
                        Loại: Rau <br>
                        Khối lượng: 1kg <br>
                        Giá đã giảm: <span style="color: red;">29.000</span> <sup>đ</sup> <br>
                        Chi tết: Tên khoa học là Brassica oleracea 
                        var capitata ruba là cây bắp cải có màu tím.
                </div>
                <h2>CAM VÀNG ÚC - 1kg</h2>
                <p>159.000<sup>đ</sup></p> 
                <button>MUA</button>
            </div>
            <div class="event-other-item">
                <img src="../uploads/dualuoinhat.jpg" alt="">
                <div class="desc">
                        Loại: Rau <br>
                        Khối lượng: 1kg <br>
                        Giá đã giảm: <span style="color: red;">29.000</span> <sup>đ</sup> <br>
                        Chi tết: Tên khoa học là Brassica oleracea 
                        var capitata ruba là cây bắp cải có màu tím.
                </div>
                <h2>DƯA LƯỚI NHẬT - 1kg</h2>
                <p>135.000<sup>đ</sup></p>
                <button>MUA</button>
            </div>
            <div class="event-other-item">
                <img src="../uploads/duahau.jpg" alt="">
                <div class="desc">
                        Loại: Rau <br>
                        Khối lượng: 1kg <br>
                        Giá đã giảm: <span style="color: red;">29.000</span> <sup>đ</sup> <br>
                        Chi tết: Tên khoa học là Brassica oleracea 
                        var capitata ruba là cây bắp cải có màu tím.
                </div>
                <h2>DƯA HẤU SEL - 3kg</h2>
                <p>148.000<sup>đ</sup></p>
                <button>MUA</button>
            </div>
            <div class="event-other-item">
                <img src="../uploads/xoaichu.jpg" alt="">
                <div class="desc">
                        Loại: Rau <br>
                        Khối lượng: 1kg <br>
                        Giá đã giảm: <span style="color: red;">29.000</span> <sup>đ</sup> <br>
                        Chi tết: Tên khoa học là Brassica oleracea 
                        var capitata ruba là cây bắp cải có màu tím.
                </div>
                <h2>XOÀI CÁT CHU - 1kg</h2>
                <p>98.000<sup>đ</sup></p>
                <button>MUA</button>
            </div>
            <div class="event-other-item">
                <img src="../uploads/nhoxanhkh.jpg" alt="">
                <div class="desc">
                        Loại: Rau <br>
                        Khối lượng: 1kg <br>
                        Giá đã giảm: <span style="color: red;">29.000</span> <sup>đ</sup> <br>
                        Chi tết: Tên khoa học là Brassica oleracea 
                        var capitata ruba là cây bắp cải có màu tím.
                </div>
                <h2>NHO XANH ÚC - 1kg</h2>
                <p>199.000<sup>đ</sup></p>
                <button>MUA</button>
            </div>
            <div class="event-other-item">
                <img src="../uploads/taojuliet.jpg" alt="">
                <div class="desc">
                        Loại: Rau <br>
                        Khối lượng: 1kg <br>
                        Giá đã giảm: <span style="color: red;">29.000</span> <sup>đ</sup> <br>
                        Chi tết: Tên khoa học là Brassica oleracea 
                        var capitata ruba là cây bắp cải có màu tím.
                </div>
                <h2>TÁO JULIET - 1kg</h2>
                <p>210.000<sup>đ</sup></p>
                <button>MUA</button>
            </div>
        </div>
        <div class="event-buttum-top">
            <i class="fa-solid fa-certificate"></i>
            <h1>RAU, CỦ, NẤM</h1>
            <div class="event-buttum-top-item">
                <p>60 khuyến mãi hấp dẫn</p>
            </div>
            <div class="event-buttum-top-item">
                <p>Rau hữu cơ</p>
            </div>
            <div class="event-buttum-top-item">
                <p>Củ hửu cơ</p>
            </div>
            <div class="event-buttum-top-item">
                <p>Rau, củ, quả đà lạt</p>
            </div>
        </div>
        <div class="event-buttum-other">
            <div class="event-buttum-other-item">
                <img src="../uploads/bapcaitrang.jpg" alt="">
                <div class="desc">
                        Loại: Rau <br>
                        Khối lượng: 1kg <br>
                        Giá đã giảm: <span style="color: red;">29.000</span> <sup>đ</sup> <br>
                        Chi tết: Tên khoa học là Brassica oleracea 
                        var capitata ruba là cây bắp cải có màu tím.
                </div>
                <h2>CẢI TÍM - 250g</h2>
                <p>30.000<sup>đ</sup></p>
                <button>MUA</button>
            </div>
            <div class="event-buttum-other-item">
                <img src="../uploads/ngotay.jpg" alt="">
                <div class="desc">
                        Loại: Rau <br>
                        Khối lượng: 1kg <br>
                        Giá đã giảm: <span style="color: red;">29.000</span> <sup>đ</sup> <br>
                        Chi tết: Tên khoa học là Brassica oleracea 
                        var capitata ruba là cây bắp cải có màu tím.
                </div>
                <h2>CẢI TÍM - 250g</h2>
                <p>30.000<sup>đ</sup></p>
                <button>MUA</button>
            </div>
            <div class="event-buttum-other-item">
                <img src="../uploads/ngo.jpg" alt="">
                <div class="desc">
                        Loại: Rau <br>
                        Khối lượng: 1kg <br>
                        Giá đã giảm: <span style="color: red;">29.000</span> <sup>đ</sup> <br>
                        Chi tết: Tên khoa học là Brassica oleracea 
                        var capitata ruba là cây bắp cải có màu tím.
                </div>
                <h2>CẢI TÍM - 250g</h2>
                <p>30.000<sup>đ</sup></p>
                <button>MUA</button>
            </div>
            <div class="event-buttum-other-item">
                <img src="../uploads/bacha.jpg" alt="">
                <div class="desc">
                        Loại: Rau <br>
                        Khối lượng: 1kg <br>
                        Giá đã giảm: <span style="color: red;">29.000</span> <sup>đ</sup> <br>
                        Chi tết: Tên khoa học là Brassica oleracea 
                        var capitata ruba là cây bắp cải có màu tím.
                </div>
                <h2>CẢI TÍM - 250g</h2>
                <p>30.000<sup>đ</sup></p>
                <button>MUA</button>
            </div>
            <div class="event-buttum-other-item">
                <img src="../uploads/bacha.jpg" alt="">
                <div class="desc">
                        Loại: Rau <br>
                        Khối lượng: 1kg <br>
                        Giá đã giảm: <span style="color: red;">29.000</span> <sup>đ</sup> <br>
                        Chi tết: Tên khoa học là Brassica oleracea 
                        var capitata ruba là cây bắp cải có màu tím.
                </div>
                <h2>CẢI TÍM - 250g</h2>
                <p>30.000<sup>đ</sup></p>
                <button>MUA</button>
            </div>
            <div class="event-buttum-other-item">
                <img src="../uploads/bacha.jpg" alt="">
                <div class="desc">
                        Loại: Rau <br>
                        Khối lượng: 1kg <br>
                        Giá đã giảm: <span style="color: red;">29.000</span> <sup>đ</sup> <br>
                        Chi tết: Tên khoa học là Brassica oleracea 
                        var capitata ruba là cây bắp cải có màu tím.
                </div>
                <h2>CẢI TÍM - 250g</h2>
                <p>30.000<sup>đ</sup></p>
                <button>MUA</button>
            </div>
        </div>
       
     
    </section>
    <hr>
    <section class="app-contenr">
        <p> Tải ứng dụng Bách Hóa Ngọc Diệp</p>
        <div class="app-google">
            <img src="../uploads/app-store.png">
            <img src="../uploads/gg-play.png">
        </div>
        <p> Nhập bản tin của Bách Hóa Ngọc Diệp</p>
        <input type="text" placeholder="Nhập email của bạn....">
    </section>
   
    <div class="footer-top">
        <li> <a href=""><img src="../uploads/thongbao.png"></a></li>
        <li> <a href="">Liên hệ</a></li>
        <li> <a href="">Tuyển dụng</a></li>
        <li> <a href="">Giới thiệu</a></li>
        <li>
            <a href=""><img src="../uploads/fb.png"></a>
            <a href=""><img src="../uploads/yt.jpg"></a>
            <a href=""><img src="../uploads/tw.png"></a>
        </li>
    </div>
    <div class="footer-center">
        <p>
           Cửa hàng Bách Hóa Ngọc Diệp với số đăng ký kinh doanh: 0105777651 <br>
            Địa chỉ đăng ký: Đường 30/4, Thị Xã Cây Lại, Tỉnh Tiền Giang<br>
            Đặt hàng online : <b>0397516328</b> .
        </p>
    </div>
    <div class="footer-bottom">
        ©NgocDiep All rights reserved
    </div>

</body>
<script>
const itemliderbar = document.querySelectorAll(".cartegory-left-li")
itemliderbar.forEach(function(menu, index){
menu.addEventListener("click", function(){
    menu.classList.toggle("block")
}) 
})

var arr_hinh = [
        "../uploads/khuyenmai1.jpg",
        "../uploads/khuyenmai2.jpg",
        "../uploads/khuyenmai3.jpg",
    ]
    var i = 0;
    function trai(){
        i--;
        if (i < 0) i = arr_hinh.length - 1;
        var hinh = document.getElementById("hinh");
        hinh.src = arr_hinh[i]; 
    }
    function phai(){
        i++;
        if (i >= arr_hinh.length) i = 0;
        var hinh = document.getElementById("hinh");
        hinh.src = arr_hinh[i]; 
    }
</script>
</html>