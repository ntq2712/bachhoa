<section class="longin-amin">
        <div class="longin-right">
            <div class="view">
                <div class="menu-view">
                    <div class="header-view">
                        <div id="toggle-view">
                            <i class="fas fa-bars"></i>
                        </div>
                        <nav>
                            <ul id="main-menu-view">
                                <li><a href="cartegorylist.php">Danh Mục</a></li>
                                <li><a href="branlist.php">Loại Sản Phẩm</a></li>
                                <li><a href="productlist.php">Sản Phẩm</a></li>
                                <li><a href="">Khách Hàng</a></li>
                                <li><a href="">Đơn Hàng</a></li>
                                <li><a href="">Hình Ảnh</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>