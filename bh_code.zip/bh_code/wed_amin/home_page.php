
<?php
    include "header_admin.php";
?>

        <section class="longin-amin">
            <div class="home">
                <div class="home-center">
                    <div class="home-items">
                        <a href="cartegory_add.php"><i class="fa-regular fa-calendar-plus"></i><br>
                            Danh mục</a>
                </div>
                <div class="home-items">
                    <a href="Brand_add.php"><i class="fa-regular fa-calendar-plus"></i><br>
                        Loại danh mục</a>
                </div>
                <div class="home-items">
                    <a href="Product_add.php"><i class="fa-regular fa-calendar-plus"></i><br>
                        Sản phẩm</a>
                </div>
                <div class="home-items">
                    <a href="cartegorylist.php">  <i class="fas fa-database"></i><br>
                        Xem dữ liệu</a>
                </div>
                <div class="home-items">
                    <a href=""><i class="fa-regular fa-eye"></i><br>
                        Khách hàng</a>
                </div>
                <div class="home-items">
                    <a href=""><i class="fas fa-bag-shopping"></i><br>
                    Đơn hàng</a>
                </div>
                <div class="home-items">
                    <a href=""><i class="fa-regular fa-eye"></i><br>
                        Giới Thiệu</a>
            </div>
                <div class="home-items">
                    <a href=""><i class="fas fa-images"></i><br>
                        Hình ảnh</a>
                </div>
            
                
                <div class="home-items">
                        <a href=""><i class="fa-solid fa-gear"></i><br>
                            Cài đặc</a>
                </div>
                </div>
                
            </div>
            
<?php
      include "bottum.php";
?>